import { prisma } from "@/lib/prisma/prisma";

export function findProfileByReg(regNo: string) {
  return prisma.profile.findUnique({
    where: { regNo },
    include: {
      permanentAddress: {
        include: {
          country: true,
        },
      },
      presentAddress: {
        include: {
          country: true,
        },
      },
      educations: {
        include: {
          institution: true,
        },
      },
      workExperiences: {
        include: {
          company: true,
        },
      },
      // Publications are linked through the publication_authors join table.
      // TODO: swap getDemoProfile() for findProfileByReg() once this relation
      // is wired up in profile.service.ts.
      publicationAuthors: {
        include: {
          publication: true,
        },
      },
    },
  });
}
