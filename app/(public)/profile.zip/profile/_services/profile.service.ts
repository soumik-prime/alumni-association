import {
  BloodGroup,
  Degree,
  EmploymentType,
  Gender,
  Industry,
} from "@/generated/prisma/enums";
import { Profile } from "../_types/profile.types";

export function getDemoProfile(): Profile {
  const profile: Profile = {
    id: "202204023",
    name: "Md. Samiul Islam Soumik",
    regNo: "202204023",
    batch: 4,
    session: "2022-23",
    graduationYear: 2028,
    photo: "/placeholder.jpeg",
    bio: "Competitive Programmer | MERN Stack Developer",
    gender: Gender.MALE,
    bloodGroup: BloodGroup.A_POSITIVE,
    email: "soumik.shu@gmail.com",
    facebook: "https://www.facebook.com/soumik.primee",
    github: "https://github.com/soumik-prime",
    linkedin: "https://www.linkedin.com/in/soumik-prime",
    googleScholar: "https://scholar.google.com",
    portfolio: "https://www.facebook.com/soumik.primee",
    presentAddress: {
      city: "Netrokona",
      country: {
        name: "Bangladesh",
      },
    },
    permanentAddress: {
      city: "Thakurgaon",
      country: {
        name: "Bangladesh",
      },
    },
    educations: [
      {
        degree: Degree.SSC,
        graduationYear: 2020,
        field: "Science",
        institution: {
          name: "Thakurgaon Govt. Boys' High School, Thakurgaon",
          website: "https://www.tgbhs.edu.bd/"
        },
      },
      {
        degree: Degree.HSC,
        institution: {
          name: "Carmichael College, Rangpur",
        },
      },
      {
        degree: Degree.PHD,
        field: "Computer Science & Engineering",
        graduationYear: 2030,
        institution: {
          name: "MIT",
        },
      },
    ],
    workExperience: [
      {
        company: {
          name: "Brain Station 23",
          industry: Industry.SOFTWARE_IT,
          website: "https://brainstation-23.com",
        },
        careerField: "Backend Development",
        title: "Software Engineer",
        employmentType: EmploymentType.FULL_TIME,
        startDate: "2025-01-15T00:00:00.000Z",
        endDate: null,
      },
      {
        company: {
          name: "Therap (BD) Ltd.",
          industry: Industry.SOFTWARE_IT,
          website: "https://therapservices.net",
        },
        careerField: "Web Development",
        title: "Software Engineering Intern",
        employmentType: EmploymentType.INTERNSHIP,
        startDate: "2024-06-01T00:00:00.000Z",
        endDate: "2024-12-15T00:00:00.000Z",
      },
    ],
    publications: [
      {
        title:
          "Optimizing Query Response Time in Sparse Graph Databases Using Bitmask DP",
        venue:
          "International Conference on Computer & Information Technology (ICCIT)",
        year: 2027,
        link: "https://scholar.google.com",
        coAuthors: ["Dr. A. Rahman", "T. Chowdhury"],
      },
      {
        title: "A Lightweight Approach to Offline-First Alumni Directories",
        venue: "NEU Journal of Computer Science, Vol. 3",
        year: 2028,
        link: "https://scholar.google.com",
      },
    ],
  };

  return profile;
}
