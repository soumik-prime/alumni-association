import type { LucideIcon } from "lucide-react";

export type NavItem = {
  label: string;
  href: string;
  icon: LucideIcon;
};

export type NavSection = {
  /** Omit for an untitled group (e.g. Overview at the top). */
  title?: string;
  items: NavItem[];
};