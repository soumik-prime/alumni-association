import PageTitle from "../_components/PageTitle";


export default function OverviewPage() {
  return <PageTitle title="Work Experience" />;
}
