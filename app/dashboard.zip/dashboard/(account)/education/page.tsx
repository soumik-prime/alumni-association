import PageTitle from "../../_components/PageTitle";


export default function EducationPage() {
  return <PageTitle title="Education History" />;
}
