import PageTitle from "../../_components/PageTitle";

export default function PublicationsPage() {
  return <PageTitle title="Publications" />;
}
