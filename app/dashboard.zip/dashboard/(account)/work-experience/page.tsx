import PageTitle from "../../_components/PageTitle";

export default function WorkExperiencePage() {
  return <PageTitle title="Work Experience" />;
}
