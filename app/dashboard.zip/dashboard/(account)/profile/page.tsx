import PageTitle from "../../_components/PageTitle";

export default function ProfilePage() {
  return <PageTitle title="Profile" />;
}
