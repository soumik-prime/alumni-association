import PageTitle from "../../_components/PageTitle";


export default function AddressesPage() {
  return <PageTitle title="Addresses" />;
}
