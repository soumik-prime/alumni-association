import PageTitle from "../../_components/PageTitle";


export default function SocialContactPage() {
  return <PageTitle title="Social & Contact" />;
}
