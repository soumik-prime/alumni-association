import PageTitle from "../../_components/PageTitle";

export default function SecurityPage() {
  return <PageTitle title="Security" />;
}
