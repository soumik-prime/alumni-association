import PageTitle from "../../_components/PageTitle";

export default function PermissionsPage() {
  return <PageTitle title="Permissions" />;
}
