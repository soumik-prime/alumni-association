import PageTitle from "../../_components/PageTitle";

export default function PermissionGroupsPage() {
  return <PageTitle title="Permission Groups" />;
}
