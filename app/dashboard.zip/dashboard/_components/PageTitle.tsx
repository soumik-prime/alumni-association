type PageTitleProps = { title: string };

export default function PageTitle({ title }: PageTitleProps) {
  return (
    <div className="mx-auto w-full max-w-5xl">
      <h1 className="text-xl font-bold text-slate-900">{title}</h1>
    </div>
  );
}
