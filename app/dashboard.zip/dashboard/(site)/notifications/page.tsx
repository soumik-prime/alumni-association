import PageTitle from "../../_components/PageTitle";


export default function NotificationsPage() {
  return <PageTitle title="Notifications" />;
}
