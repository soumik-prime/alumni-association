import PageTitle from "../../_components/PageTitle";

export default function UsersPage() {
  return <PageTitle title="Users" />;
}
